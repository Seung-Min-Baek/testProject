import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

public class ChatGPT {

	private static String API_KEY = "sk-proj-HKbMT4of1gvaoeUtYLj3T3BlbkFJFElzOJ9dgEMaFMbcwIGq";
	private static String GPT_URL = "https://api.openai.com/v1/chat/completions";
	
	public static void main(String[] args) throws IOException { //Exception > IOException > MalformedURLExpetion
		URL url = new URL(GPT_URL);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		
		//URL 정보 설정 정보 가져오기 : get 정보 보내기 : post
		connection.setRequestMethod("POST");
		connection.setRequestProperty("Content-Type", "application/json"); // 데이터를 주고 받을 때 json 형태로 주고 받겠다.
		connection.setRequestProperty("Authorization", "Bearer " + API_KEY); //(key,value) 형태
		connection.setDoInput(true);
		connection.setDoOutput(true);
		
		JSONObject data = new JSONObject();
		data.put("model", "gpt-3.5-turbo");
		data.put("temperature",0.7);
		
		// 어떤 데이터를 보내줄 것인지 
		JSONObject message = new JSONObject();
		message.put("role", "user");
		message.put("content", "안녕? Chat GPT에 대해 자세하게 소개해줘.");
		
		// 데이터를 JSON 배열에 넣기
		JSONArray messages = new JSONArray();
		messages.put(message);
		
		data.put("messages", messages);
		
		// 데이터를 통신보내는 것 : BufferedWriter
		// data를 연속으로 저장할때 stream 사용
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream()));
		// 문자열로  data 출력
		bw.write(data.toString());
		bw.flush(); //bw에 남아있는 데이터를 비워주겠다.
		bw.close();
		
		// 데이터를 읽어오는 것 : BufferedReader
		BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
		StringBuilder sb = new StringBuilder();
		String line = null;
		
		while ((line = br.readLine()) != null) {
			sb.append(line);
		}
		
		System.out.println(sb.toString());
	}

}
